using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ExitButtons : MonoBehaviour
{
    public void ExitGame()
    {
        Application.Quit();
    }
}
