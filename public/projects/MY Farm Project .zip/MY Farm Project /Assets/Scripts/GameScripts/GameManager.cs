using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static int Tomato;
    public static int Chickens;
    public static int Potato;
    public static int Potatoseed;
    public static int tomatoseed;

    // Start is called before the first frame update
    void Start()
    {
        Tomato = 6;
        Chickens = 3;
        Potato = 6;
        tomatoseed = 1;
        Potatoseed = 1;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
